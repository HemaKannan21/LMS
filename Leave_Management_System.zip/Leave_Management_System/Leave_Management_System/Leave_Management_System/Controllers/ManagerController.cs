﻿using Leave_Management_System.Models;
using Leave_Management_System.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Leave_Management_System.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ManagerController : ControllerBase
    {
        private readonly IManagerRepo managerRepo;

        public ManagerController(IManagerRepo managerRepo)
        {
            this.managerRepo = managerRepo;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllEmp()
        {
            var employees = await managerRepo.GetAllManager();
            return Ok(employees);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> SearchById(int id)
        {
            var employees = await managerRepo.GetManagerById(id);
            return Ok(employees);
        }

        [HttpPost]
        public async Task<IActionResult> AddMang(Manager manager)
        {
            var managers = await managerRepo.AddManager(new Manager { ManagerPassword = manager.ManagerPassword, FullName = manager.FullName, ManagerEmailId = manager.ManagerEmailId, ManagerMobileNo = manager.ManagerMobileNo });
            return Ok(managers);
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteMang(int id)
        {
            var managers = await managerRepo.DeleteManager(id);
            return Ok(managers);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateMang(int id, Manager manager)
        {
            var managers = await managerRepo.UpdateManager(id, manager);
            return Ok(managers);
        }

        [HttpGet("{id}/{Password}")]
        public async Task<IActionResult> Login(int id, string Password)
        {
            var managers = await managerRepo.Login(id, Password);
            return Ok(managers);
        }
    }
}
