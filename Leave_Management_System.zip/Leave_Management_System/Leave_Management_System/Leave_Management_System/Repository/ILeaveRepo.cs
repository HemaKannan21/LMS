﻿using Leave_Management_System.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Leave_Management_System.Repository
{
    public interface ILeaveRepo
    {
        Task<List<EmployeeLeave>> GetAllLeave();

        Task<EmployeeLeave> GetLeaveById(int id);

        Task<int> ApplyLeave(EmployeeLeave employeeLeave);

        Task<int> ApproveDeny(int levid, EmployeeLeave employeeLeave);

        Task<int> DeleteLeave(int id);

    }
}
